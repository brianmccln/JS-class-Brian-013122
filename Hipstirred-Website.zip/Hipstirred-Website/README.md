# Hipstirred-Website Project
This website is about Hipstirred coffee. It uses HTML and CSS so far, 
but hopefully will soon add JavaScript and maybe some day even have a backend database connected.
